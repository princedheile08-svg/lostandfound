# ICCT Lost & Found

Static frontend (`public/`) + serverless Node.js API (`api/`) + MySQL.

## Option A: GitHub Pages only (works with zero setup)
1. Push this repo to GitHub (branch `main`).
2. Settings → Pages → Source: **GitHub Actions**.
3. Push again (or run the "Deploy to GitHub Pages" workflow). Your site goes live at `https://<you>.github.io/<repo>/`.

This runs in **demo mode**: reports are saved in the visitor's browser only, staff password is `demo`, and AI is off. GitHub cannot host a database, so use Option B for real shared data.

## Option B: Real database (Vercel + MySQL)
1. Create a MySQL database (TiDB Cloud Serverless, PlanetScale, Aiven or Railway) and copy its connection string.
2. Import the repo at vercel.com/new. Add env vars from `.env.example`: `DATABASE_URL`, `AUTH_SECRET`, `STAFF_PASSWORD`, `ADMIN_PASSWORD`, optional `ANTHROPIC_API_KEY`.
3. Deploy. The `items` table is created automatically (`schema.sql`) and seeded with sample reports.

The Vercel site is now the full app. To keep the GitHub Pages site too, but backed by the real database:
- On Vercel set `ALLOWED_ORIGIN=https://<you>.github.io`.
- On GitHub: Settings → Secrets and variables → Actions → Variables → add `API_BASE` = your Vercel URL (e.g. `https://my-app.vercel.app`), then re-run the Pages workflow.

## Roles
Anyone can browse and report. Staff can mark items claimed; Admin can also delete. Checked server-side with a signed token.

## Local
`npm i -g vercel && npm i && vercel dev`
